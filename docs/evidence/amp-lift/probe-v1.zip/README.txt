Failed fresh-process parity probe, 10 actions per run, 0.2 seconds. This is not a full lift evaluation.
The compiled MJB/meshes, checkpoint and motion clips are not redistributed. The numerical arrays suffice for offline scoring.
Original failed qualification and scorer failure are preserved. The corrected scorer identifies world-welded terrain.
From the reviewed DexLab checkout: python demos/amp-box-lift/score.py --run <unpacked>/runs/probe-recorded-1 --output <fresh-directory>
No additional physics, training, native attempt or qualification override is performed by this command.
Model/visual attribution: humanoid-amp-ppo 4889389; Unitree G1 (BSD-3-Clause); RoboCasa Toaster003 (CC BY 4.0), see source/demos/amp-box-lift/provenance.json. Model adaptations by the AMP source are retained in the reference.
